//header files inclusion
#include <stdio.h>
#include<stdlib.h>
#include <string.h>
#include <ctype.h>
//function prototypes
void view_mp3(char song[]);
void edit_mp3(char[], char[], char[]);
void help_mp3();
int convert(int);
